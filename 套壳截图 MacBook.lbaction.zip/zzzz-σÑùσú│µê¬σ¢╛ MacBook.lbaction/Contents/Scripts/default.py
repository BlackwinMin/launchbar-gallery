#!/usr/bin/env python
#
# LaunchBar Action Script
#
import sys
import subprocess as sp
import os
import json
import shutil

my_env = os.environ.copy()
my_env["PATH"] = "/usr/local/bin:" + my_env["PATH"]
# Note: The first argument is the script's path

low_image = "MacBook.jpg"

for arg in sys.argv[1:]:
        fileFolder = os.path.dirname(arg)
        fileName = os.path.basename(arg)
        newFile = fileFolder + "/new-" + fileName
        my_command = ["composite", "-geometry", "+466+140", arg, low_image, newFile]
        sp.check_output(my_command, env=my_env)
os.system('sh noti.sh')
