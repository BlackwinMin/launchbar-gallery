#!/bin/bash

afplay "/System/Library/Sounds/Submarine.aiff"